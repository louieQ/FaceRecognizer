#!/bin/sh

#  AutoCropper.sh
#  Created by Luigi Quaranta on 17/03/16.
#


# Mi posiziono nella cartella in cui è contenuto lo script.
# Nella stessa cartella devono trovarsi gli eseguibili java e il file basic_script.py!
parent_path=$( cd "$(dirname "${BASH_SOURCE}")" ; pwd -P )
cd "$parent_path"


echo "Copia qui il percorso della cartella con le immagini:"
read imgs_path
java -jar EyesCoordinates.jar "$imgs_path" basic_script.py

cd "$imgs_path"
cd ..
python crop_script.py
rm crop_script.py

cd "$parent_path"
echo "Indica il percorso dove si troverà la cartella con le immagini in ubuntu:"
read ubuntu_path
java -jar CSVForOpenCV.jar "$imgs_path"_cropped "$ubuntu_path"

cd "$imgs_path"
cd .. 

echo "Indica il percorso della cartella condivisa con ubuntu:"
read sharedFolder_path
mv "${imgs_path##*/}"_cropped "$sharedFolder_path"
mv "${imgs_path##*/}"_cropped.csv "$sharedFolder_path"

echo "Everything's OK, see you! :)"