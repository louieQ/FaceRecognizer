#!/bin/sh

echo "Copia qui il percorso della cartella di partenza:"
read imgs_source

cd $imgs_source

echo "Copia qui il percorso della cartella di destinazione:"
read imgs_dest

for filename in *.jpg
    do
        open $filename
        sleep 1
        open -a Terminal
        read -p "Ti serve questa immagine? " -n 1 -r
        if [[ $REPLY =~ ^[YySs]$ ]]
        then cp $imgs_source/$filename $imgs_dest
        fi
done

